-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 03. September 2011 um 10:00
-- Server Version: 5.5.8
-- PHP-Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `game`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_planeten`
--

CREATE TABLE IF NOT EXISTS `game_planeten` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `bild` longblob NOT NULL,
  `buildres` text COLLATE latin1_general_ci NOT NULL,
  `res` text COLLATE latin1_general_ci NOT NULL,
  `buildship` text COLLATE latin1_general_ci NOT NULL,
  `buildtroop` text COLLATE latin1_general_ci NOT NULL,
  `names` text COLLATE latin1_general_ci NOT NULL,
  `bewohnbar` int(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_race`
--

CREATE TABLE IF NOT EXISTS `game_race` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `bild` longblob NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_ships`
--

CREATE TABLE IF NOT EXISTS `game_ships` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `Power` int(200) NOT NULL,
  `health` int(100) NOT NULL,
  `names` text COLLATE latin1_general_ci NOT NULL,
  `costs` text COLLATE latin1_general_ci NOT NULL,
  `picture` longblob NOT NULL,
  `time` int(100) NOT NULL,
  `race` text COLLATE latin1_general_ci NOT NULL,
  `speed` int(100) NOT NULL DEFAULT '10',
  `skills` text COLLATE latin1_general_ci NOT NULL,
  `globallimit` int(100) NOT NULL,
  `need_tech` text COLLATE latin1_general_ci NOT NULL,
  `Resistend1` int(100) NOT NULL,
  `Power2` int(100) NOT NULL,
  `Resistend2` int(100) NOT NULL,
  `Power3` int(100) NOT NULL,
  `Resistend3` int(100) NOT NULL,
  `Power4` int(100) NOT NULL,
  `Resistend4` int(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_skills`
--

CREATE TABLE IF NOT EXISTS `game_skills` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `beschreibung` text COLLATE latin1_general_ci NOT NULL,
  `skill` text COLLATE latin1_general_ci NOT NULL,
  `need` text COLLATE latin1_general_ci NOT NULL,
  `picture` longblob NOT NULL,
  `states` text COLLATE latin1_general_ci NOT NULL,
  `passiv` int(1) NOT NULL,
  `ship` int(1) NOT NULL,
  `stat` int(1) NOT NULL,
  `troop` int(1) NOT NULL,
  `time` int(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_solarsystems`
--

CREATE TABLE IF NOT EXISTS `game_solarsystems` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `planets` text COLLATE latin1_general_ci NOT NULL,
  `distance` int(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_stations`
--

CREATE TABLE IF NOT EXISTS `game_stations` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `names` text COLLATE latin1_general_ci NOT NULL,
  `costs` text COLLATE latin1_general_ci NOT NULL,
  `Power` int(100) NOT NULL,
  `health` int(100) NOT NULL,
  `buildship` text COLLATE latin1_general_ci NOT NULL,
  `buildtroop` text COLLATE latin1_general_ci NOT NULL,
  `buildres` text COLLATE latin1_general_ci NOT NULL,
  `res` text COLLATE latin1_general_ci NOT NULL,
  `updateto` int(100) NOT NULL,
  `picture` longblob NOT NULL,
  `limit` int(100) NOT NULL,
  `globallimit` int(100) NOT NULL,
  `race` text COLLATE latin1_general_ci NOT NULL,
  `need` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `needcount` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `skills` text COLLATE latin1_general_ci NOT NULL,
  `need_tech` text COLLATE latin1_general_ci NOT NULL,
  `Resistend1` int(100) NOT NULL,
  `Resistend2` int(100) NOT NULL,
  `Resistend3` int(100) NOT NULL,
  `Resistend4` int(100) NOT NULL,
  `Power2` int(100) NOT NULL,
  `Power3` int(100) NOT NULL,
  `Power4` int(100) NOT NULL,
  `time` int(100) NOT NULL,
  `population` int(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_tech`
--

CREATE TABLE IF NOT EXISTS `game_tech` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `beschreibung` text COLLATE latin1_general_ci NOT NULL,
  `time` int(100) NOT NULL,
  `costs` text COLLATE latin1_general_ci NOT NULL,
  `need` text COLLATE latin1_general_ci NOT NULL,
  `race` text COLLATE latin1_general_ci NOT NULL,
  `update` text COLLATE latin1_general_ci NOT NULL,
  `group` int(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_update`
--

CREATE TABLE IF NOT EXISTS `game_update` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `shiptype` int(100) NOT NULL DEFAULT '0',
  `stattype` int(100) NOT NULL DEFAULT '0',
  `trooptype` int(100) NOT NULL DEFAULT '0',
  `strength` int(100) NOT NULL DEFAULT '0' COMMENT 'Wird zu Power addiert,  wenn update_Ckeck() auferufen wird.',
  `strength2` int(100) NOT NULL,
  `strength3` int(100) NOT NULL,
  `strength4` int(100) NOT NULL,
  `resistend1` int(100) NOT NULL,
  `resistend2` int(100) NOT NULL,
  `resistend3` int(100) NOT NULL,
  `resistend4` int(100) NOT NULL,
  `speed` int(100) NOT NULL DEFAULT '0',
  `time` int(100) NOT NULL DEFAULT '0' COMMENT 'Diese Zahl wird von der Bauzeit abgezogen.',
  `metal` int(100) NOT NULL DEFAULT '0' COMMENT 'Dieser Wert wird von der jeweiligen Resource abgezogen.',
  `water` int(100) NOT NULL DEFAULT '0' COMMENT 'Dieser Wert wird von der jeweiligen Resource abgezogen.',
  `food` int(100) NOT NULL DEFAULT '0' COMMENT 'Dieser Wert wird von der jeweiligen Resource abgezogen.',
  `naquadah` int(100) NOT NULL DEFAULT '0' COMMENT 'Dieser Wert wird von der jeweiligen Resource abgezogen.',
  `skills` text NOT NULL COMMENT 'Die Skills die dem Schiff  hinzugefügt werden',
  `hide` int(100) NOT NULL COMMENT 'Nur für Bodentruppen, steigert Tarfaktor',
  PRIMARY KEY (`ID`),
  KEY `UID` (`shiptype`,`stattype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `game_user`
--

CREATE TABLE IF NOT EXISTS `game_user` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pass` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `name` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nachname` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `level` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lastlogin` int(80) NOT NULL DEFAULT '0',
  `bild` longblob NOT NULL,
  `race` int(10) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
